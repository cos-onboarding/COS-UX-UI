$( document ).ready(function() {
    $('.selectize').selectize({
    	allowEmptyOption: true,
    });
});
