 $( document ).ready(function() {
	 $('[data-toggle="popover"]').popover( { html : true });
	 $('.single-slider').jRange({
	    from: 0,
	    to: 200,
	    step: 20,
	    scale: [0,'','','','500K','','','','','1m','','','','','1.5m','','','','','2m'],
	    //format: '%s',
	    width: '100%',
	    showLabels: false
	});
	// Hide/show animation hamburger function
	$('.navbar-toggler').on('click', function () {

	// Take this line to first hamburger animations
	$('.animated-icon1').toggleClass('open');

	// Take this line to second hamburger animation
	$('.animated-icon3').toggleClass('open');

	// Take this line to third hamburger animation
	$('.animated-icon4').toggleClass('open');
	});
//     console.log( "ready!" );
//     AOS.init();
});
